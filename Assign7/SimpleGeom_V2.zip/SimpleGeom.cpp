// SIMPLEGEOM library - EE219 design and implementation example
// Version 2.1
// CMA - 12/20/2021 - DCU

#include "SimpleGeom.h"

namespace SimpleGeom {

/***********************
 Coord class
************************/

void Coord::rotate(double angle) {
    double tmp_x = _x * cos(angle) - _y * sin(angle);
    double tmp_y = _x * sin(angle) + _y * cos(angle);
    _x = tmp_x;
    _y = tmp_y;
}

void Coord::rotate(double angle, const Coord & cRef) {
    moveBy(-cRef._x, -cRef._y);
    rotate(angle);
    moveBy(cRef._x, cRef._y);
}

bool Coord::isEqual(const Coord & otherCoord) const {
    return (_x == otherCoord._x) && (_y == otherCoord._y);
}

double Coord::distanceTo(const Coord & otherCoord) const {
    double x_diff = _x - otherCoord._x;
    double y_diff = _y - otherCoord._y;
    return sqrt(x_diff*x_diff + y_diff*y_diff);
}

/***********************
 Point class
************************/

void Point::moveBy(double x, double y) {
    coord.moveBy(x, y);
}

void Point::rotate(double angle, const Coord & cRef) {
    coord.rotate(angle, cRef);
}

void Point::draw() { cout << "Point::draw() not implemented." << endl; }

void Point::print() {
    coord.print();
    clr.print();
}

/***********************
 Line class
************************/

void Line::moveBy(double x, double y) {
    coord1.moveBy(x,y); coord2.moveBy(x,y);
}

void Line::rotate(double angle, const Coord & cRef) {
    coord1.rotate(angle, cRef);
    coord2.rotate(angle, cRef);
}

void Line::draw() { cout << "Line::draw() not implemented." << endl; }

void Line::print() {
    coord1.print();
    cout << " - ";
    coord2.print();
    cout << " Line Color: ";
    clr.print();
}

bool Line::contains(const Coord & otherCoord) const {
    double dist1 = coord1.distanceTo(otherCoord) + otherCoord.distanceTo(coord2);
    double dist2 = coord1.distanceTo(coord2);
    return fabs(dist1 - dist2) < _machine_epsilon_double;
}

Coord Line::intersection(const Line & l1, const Line & l2) {
    // first find intersection between lines of infinite extent
    double x1 = l1.coord1.x(), y1 = l1.coord1.y();
    double x2 = l1.coord2.x(), y2 = l1.coord2.y();
    double x3 = l2.coord1.x(), y3 = l2.coord1.y();
    double x4 = l2.coord2.x(), y4 = l2.coord2.y();
    double denom = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4);
    double x_numer = (x1*y2 - y1*x2)*(x3-x4) - (x1-x2)*(x3*y4-y3*x4);
    double y_numer = (x1*y2 - y1*x2)*(y3-y4) - (y1-y2)*(x3*y4-y3*x4);
    Coord intersectionCoord(x_numer/denom, y_numer/denom);
    // now check if intersection point lies on both line segments
    if (l1.contains(intersectionCoord) && l2.contains(intersectionCoord))
        return intersectionCoord;
    return NULL_COORD;
}

/***********************
 Triange class
************************/

void Triangle::moveBy(double x, double y) {
    coord1.moveBy(x,y);
    coord2.moveBy(x,y);
    coord3.moveBy(x,y);
}

void Triangle::rotate(double angle, const Coord & cRef) {
    coord1.rotate(angle, cRef);
    coord2.rotate(angle, cRef);
    coord3.rotate(angle, cRef);
}

void Triangle::draw() { cout << "Triangle::draw() not implemented." << endl; }

void Triangle::print() {
    coord1.print();
    cout << " - ";
    coord2.print();
    cout << " - ";
    coord3.print();
    cout << " Triangle Color: ";
    clr.print();
}

} // namespace SimpleGeom
