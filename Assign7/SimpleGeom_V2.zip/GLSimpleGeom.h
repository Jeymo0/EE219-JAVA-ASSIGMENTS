#ifndef GLSIMPLEGEOM_H_INCLUDED
#define GLSIMPLEGEOM_H_INCLUDED

#include "SimpleGeom.h"

#ifdef SIMPLEGEOM_GL
#include <GL/glut.h>
#include <GL/freeglut.h>
#endif

namespace SimpleGeom {

/***********************
 GLPoint class
************************/

class GLPoint : public Point {
public:
    GLPoint(const Coord & c) : Point(c) {}
    GLPoint(const Coord & c, const Color & color) : Point(c, color) {}
    GLPoint * clone() const override { return new GLPoint(*this); }

    void draw() override {
        #ifdef SIMPLEGEOM_GL
        glBegin(GL_POINTS);
        glColor3f(clr.r(), clr.g(), clr.b());
        glVertex2i(coord.x(), coord.y());
        glEnd();
        #endif
    }
};

/***********************
 GLLine class
************************/

class GLLine : public Line {
public:
    GLLine(const Coord & c1, const Coord & c2) : Line(c1, c2) {}
    GLLine(const Coord & c1, const Coord & c2, const Color & color) : Line(c1, c2, color) {}
    GLLine * clone() const override { return new GLLine(*this); }

    void draw() override {
        #ifdef SIMPLEGEOM_GL
        glBegin(GL_LINES);
        glColor3f(clr.r(), clr.g(), clr.b());
        glVertex2i(coord1.x(), coord1.y());
        glVertex2i(coord2.x(), coord2.y());
        glEnd();
        #endif
    }
};

/***********************
 GLTriangle class
************************/

class GLTriangle : public Triangle {
public:
    GLTriangle(const Coord & c1, const Coord & c2, const Coord & c3)
    : Triangle(c1, c2, c3) {}
    GLTriangle(const Coord & c1, const Coord & c2, const Coord & c3, const Color & color)
    : Triangle(c1, c2, c3, color) {}
    GLTriangle * clone() const override { return new GLTriangle(*this); }

    void draw() override {
        GLLine ln1(coord1, coord2, clr);
        GLLine ln2(coord2, coord3, clr);
        GLLine ln3(coord3, coord1, clr);
        ln1.draw();
        ln2.draw();
        ln3.draw();
    }
};

} // namespace SimpleGeom

#endif // GLSIMPLEGEOM_H_INCLUDED
