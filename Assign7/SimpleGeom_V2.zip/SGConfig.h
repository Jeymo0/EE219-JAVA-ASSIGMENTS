// SIMPLEGEOM library - EE219 design and implementation example
// Version 2.0
// CMA - 15/20/2021 - DCU
// Use this code freely

#ifndef SGCONFIG_H_INCLUDED
#define SGCONFIG_H_INCLUDED

// Keep this SIMPLEGEOM_GL define to use GLUT/OpenGL graphics
// Comment out this line to use HTML/JS drawing output instead
// #define SIMPLEGEOM_GL

// To take accont of machine precision in computational geometry calcs,
// use a value larger than the machine epsilon as precision limit
#define _machine_epsilon_double 1e-10

#endif // SGCONFIG_H_INCLUDED
