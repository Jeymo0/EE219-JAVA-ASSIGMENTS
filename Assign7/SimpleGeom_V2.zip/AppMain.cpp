#include "DrawingExamples.cpp"

using namespace SimpleGeom;

#ifdef SIMPLEGEOM_GL

#include "GLSimpleGeom.h"
/**********************************
 Draw using OpenGL/GLUT

 GLUT Drawing Callback Function
 Requires SIMPLEGEOM_GL to be defined
 in SGConfig.h

 Called by GLUT from GLSysMain.cpp
 Create a canvas here, add Shapes
 to it and then call draw()
***********************************/
void glutDrawingMain() {
    Canvas canvas(100000);
    // polygon <GLLine> (canvas, 7, YELLOW);
    // randomPoints <GLPoint> (canvas);
    // triangleFun <GLPoint, GLTriangle> (canvas);
    intersectLines <GLPoint, GLLine> (canvas, 50);
    // fractalTrees <GLPoint, GLLine> (canvas);
    canvas.draw();
}

#else

#include "JSSimpleGeom.h"
/**********************************
 Draw to HTML/JavaScript output file

 SIMPLEGEOM_GL should not be defined
 (commented out) in SGConfig.h

 Create a JSCanvas here, add Shapes
 to it and then call draw() on
 canvas to output to file
***********************************/
int main() {
    JSCanvas canvas1(1000, "trianglesDrawing.html", "1000", "1000");
    triangleFun <JSPoint,JSTriangle> (canvas1);
    canvas1.draw();

    JSCanvas canvas2(1000000, "fractalTreeDrawing.html", "2000", "1000");
    fractalTrees <JSPoint, JSLine> (canvas2);
    canvas2.draw();

    JSCanvas canvas3(1000000, "intersectingLines.html", "810", "810");
    intersectLines <JSPoint, JSLine> (canvas3);
    canvas3.draw();
}

#endif
