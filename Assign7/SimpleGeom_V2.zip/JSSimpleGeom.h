#ifndef SIMPLEGEOMJS_H_INCLUDED
#define SIMPLEGEOMJS_H_INCLUDED

#include "SimpleGeom.h"
#include <fstream>
#include <string>
using std::ofstream;
using std::to_string;

namespace SimpleGeom {

string _JSOutString;

/***********************
 JSPoint class
************************/

class JSPoint : public Point {
public:
    JSPoint(const Coord & c) : Point(c) {}
    JSPoint(const Coord & c, const Color & color) : Point(c, color) {}
    JSPoint * clone() const override { return new JSPoint(*this); }

    void draw() override {
        _JSOutString += "context.fillStyle = 'rgb(";
        _JSOutString += clr.r255() + "," + clr.g255() + "," + clr.b255() + ")';\n";
        _JSOutString += "context.beginPath();\n";
        _JSOutString += "context.arc(" + to_string(x()) + "," + to_string(y());
        _JSOutString += ", 2, 0, 2 * Math.PI, false);\n";
        _JSOutString += "context.fill();\n";
    }
};

/***********************
 JSLine class
************************/

class JSLine : public Line {
public:
    JSLine(const Coord & c1, const Coord & c2) : Line(c1, c2) {}
    JSLine(const Coord & c1, const Coord & c2, const Color & color) : Line(c1, c2, color) {}
    JSLine * clone() const override { return new JSLine(*this); }

    void draw() override {
        _JSOutString += "context.strokeStyle = 'rgb(";
        _JSOutString += clr.r255() + "," + clr.g255() + "," + clr.b255() + ")';\n";
        _JSOutString += "context.beginPath();\n";
        _JSOutString += "context.moveTo(" + to_string(coord1.x());
        _JSOutString += "," + to_string(coord1.y()) + ");\n";
        _JSOutString += "context.lineTo(" + to_string(coord2.x());
        _JSOutString += "," + to_string(coord2.y()) + ");\n";
        _JSOutString += "context.stroke();\n";
    }
};

/***********************
 JSTriangle class
************************/

class JSTriangle : public Triangle {
public:
    JSTriangle(const Coord & c1, const Coord & c2, const Coord & c3)
    : Triangle(c1, c2, c3) {}
    JSTriangle(const Coord & c1, const Coord & c2, const Coord & c3, const Color & color)
    : Triangle(c1, c2, c3, color) {}
    JSTriangle * clone() const override { return new JSTriangle(*this); }

    void draw() override {
        _JSOutString += "context.strokeStyle = 'rgb(";
        _JSOutString += clr.r255() + "," + clr.g255() + "," + clr.b255() + ")';\n";
        _JSOutString += "context.beginPath();\n";
        _JSOutString += "context.moveTo(" + to_string(coord1.x());
        _JSOutString += "," + to_string(coord1.y()) + ");\n";
        _JSOutString += "context.lineTo(" + to_string(coord2.x());
        _JSOutString += "," + to_string(coord2.y()) + ");\n";
        _JSOutString += "context.lineTo(" + to_string(coord3.x());
        _JSOutString += "," + to_string(coord3.y()) + ");\n";
        _JSOutString += "context.lineTo(" + to_string(coord1.x());
        _JSOutString += "," + to_string(coord1.y()) + ");\n";
        _JSOutString += "context.stroke();\n";
    }

};

/***********************
 JSCanvas class
************************/

class JSCanvas : public Canvas {
private:
    string outFileName;                 // HTML output file name
    string xDim;                        // HTML canvas size in X direction
    string yDim;                        // HTML canvas size in Y direction
public:
    JSCanvas(int max_elements, std::string outFile)
    : Canvas(max_elements), outFileName(outFile), xDim("600"), yDim("600") {
        _JSOutString = "";
    }
    JSCanvas(int max_elements, std::string outFile, string xdim, string ydim)
    : Canvas(max_elements), outFileName(outFile), xDim(xdim), yDim(ydim) {
        _JSOutString = "";
    }

    void draw() override {
        // HTML output file header
        _JSOutString += "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n";
        _JSOutString += "<meta charset=\"utf-8\">\n<title>SimpleGeom Drawing</title>\n";
        _JSOutString += "<style>\n  canvas { border: 1px solid #000; }\n</style>\n";
        _JSOutString += "<script>\n";
        _JSOutString += "window.onload = function() {\n";
        _JSOutString += "var canvas = document.getElementById(\"myCanvas\");\n";
        _JSOutString += "var context = canvas.getContext(\"2d\");\n";
        _JSOutString += "context.fillStyle = \"black\";\n";
        _JSOutString += "context.fillRect(0, 0, canvas.width, canvas.height);\n";
        // Generate JavaScript drawing commands
        for (int i=0; i<numShapes; i++) sArray[i]->draw();
        // HTML output file footer
        _JSOutString += "};\n</script>\n</head>\n<body>\n";
        _JSOutString += "  <canvas id=\"myCanvas\" width=\"" + xDim + "\"" + "height=\"" + yDim + "\"></canvas>\n";
        _JSOutString += "</body>\n</html>\n";
        // Save the JS string to file
        ofstream outHTMLFile;
        outHTMLFile.open(outFileName);
        if(outHTMLFile) {
            outHTMLFile << _JSOutString;
            outHTMLFile.close();
            cout << "JavaScript drawing was created in: " << outFileName << endl;
        }
        else {
            cout << "Error opening output file: " << outFileName << endl;
        }
    }

};

} // namespace SimpleGeom

#endif // SIMPLEGEOMJS_H_INCLUDED
