#include "SGConfig.h"

#ifdef SIMPLEGEOM_GL

#include <GL/glut.h>

void reshape(int, int);
void display(void);
void keyboardFunc(unsigned char, int, int);

int main(int argc, char **argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(1800, 1000);
    glutInitWindowPosition(1,1);
    glutCreateWindow("EE219 SimpleGeom Drawing");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, w, 0, h, -1, 1);
    glScalef(1, -1, 1);
    glTranslatef(0, -h, 0);
}

extern void glutDrawingMain();

void display(void) {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glPointSize(3.0);
    glutDrawingMain();

    glFlush();
}

#endif
