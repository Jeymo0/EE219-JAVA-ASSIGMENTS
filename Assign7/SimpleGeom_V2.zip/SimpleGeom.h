#ifndef SIMPLEGEOM_H_INCLUDED
#define SIMPLEGEOM_H_INCLUDED

#include "SGConfig.h"

#include <iostream>
#include <string>
#include <math.h>
#include <limits>
using std::cout;
using std::endl;
using std::string;

namespace SimpleGeom {

#define PI acos(-1)

/***********************
 Color class
************************/

class Color {
private:
    double _r, _g, _b;
public:
    Color() : _r(0.5), _g(0.5), _b(0.5) {}
    Color(double r, double g, double b) : _r(r), _g(g), _b(b) {}
    double r() { return _r; }
    double g() { return _g; }
    double b() { return _b; }
    string r255() { return std::to_string((int)(_r * 255)); }
    string g255() { return std::to_string((int)(_g * 255)); }
    string b255() { return std::to_string((int)(_b * 255)); }
    void print() { cout << "[" << _r << "," << _g << "," << _b << "]"; }
};

/***********************
 Define Standard Colors
************************/

#define BLACK       Color(0,0,0)
#define WHITE       Color(1,1,1)
#define RED         Color(1,0,0)
#define DARK_RED    Color(0.5,0,0)
#define GREEN       Color(0,1,0)
#define DARK_GREEN  Color(0,0.5,0)
#define BLUE        Color(0,0,1)
#define DARK_BLUE   Color(0,0,0.5)
#define YELLOW      Color(1,1,0)
#define PINK        Color(1,0,1)
#define CYAN        Color(0,1,1)
#define ORANGE      Color(1,0.5,0)
#define GRAY        Color(0.5,0.5,0.5)
#define LIGHT_GRAY  Color(0.8,0.8,0.8)

/***********************
 Coord class
************************/

#define  MIN_DOUBLE_VAL  std::numeric_limits<double>::min()
#define  NULL_COORD      Coord(MIN_DOUBLE_VAL, MIN_DOUBLE_VAL)

class Coord {
private:
    double _x, _y;
public:
    Coord(double x, double y) : _x(x), _y(y) {}
    double x() const { return _x; }
    double y() const { return _y; }
    void moveBy(double x, double y) { _x += x; _y += y; }
    void rotate(double angle);
    void rotate(double angle, const Coord & rRef);
    void print() {
        if (this->isEqual(NULL_COORD)) cout << "NULL_COORD ";
        else cout << "(" << _x << "," << _y << ") ";
    }
    bool isEqual(const Coord & otherCoord) const;
    double distanceTo(const Coord & otherCoord) const;
};

/***********************
 Shape class
************************/

class Shape {
protected:
    Color clr;
public:
    Shape() : clr(0.5,0.5,0.5) {};
    Shape(const Color & color) : clr(color) {}
    void setColor(const Color & color) { clr = color; }
    virtual void moveBy(double x, double y) = 0;
    virtual void rotate(double angle, const Coord & cRef) = 0;
    virtual void draw() = 0;
    virtual void print() = 0;
    virtual Shape * clone() const = 0;
    virtual ~Shape() {};
};

/***********************
 Point class
************************/

class Point : public Shape {
protected:
    Coord coord;
    void rotate(double angle) { coord.rotate(angle); }
public:
    Point(const Coord & c) : coord(c) {}
    Point(const Coord & c, const Color & color) : Shape(color), coord(c) {}
    double x() { return coord.x(); }
    double y() { return coord.y(); }
    void moveBy(double x, double y) override;
    void rotate(double angle, const Coord & cRef) override;
    virtual void draw() override;
    void print() override;
    virtual Point * clone() const override { return new Point(*this); }
};

/***********************
 Line class
************************/

class Line : public Shape {
protected:
    Coord coord1, coord2;
public:
    Line(const Coord & c1, const Coord & c2) : coord1(c1), coord2(c2) {}
    Line(const Coord & c1, const Coord & c2, const Color & color) : Shape(color), coord1(c1), coord2(c2) {}
    void moveBy(double x, double y) override;
    void rotate(double angle, const Coord & cRef) override;
    virtual void draw() override;
    void print() override;
    virtual Line * clone() const override { return new Line(*this); }
    bool contains(const Coord & otherCoord) const;
    static Coord intersection(const Line & l1, const Line & l2);
};

/***********************
 Triange class
************************/

class Triangle : public Shape {
protected:
    Coord coord1, coord2, coord3;
public:
    Triangle(const Coord & c1, const Coord & c2, const Coord & c3) :
        coord1(c1), coord2(c2), coord3(c3) {}
    Triangle(const Coord & c1, const Coord & c2, const Coord & c3, const Color & color) :
        Shape(color), coord1(c1), coord2(c2), coord3(c3) {}
    void moveBy(double x, double y) override;
    void rotate(double angle, const Coord & cRef) override;
    virtual void draw() override;
    void print() override;
    virtual Triangle * clone() const override { return new Triangle(*this); }
};

/***********************
 Canvas class
************************/

class Canvas {
protected:
    const int maxElements;
    int numShapes;
    Shape** sArray; // array of Shape pointers
public:
    Canvas(int max_elements) : maxElements(max_elements), numShapes(0) {
        sArray = new Shape*[maxElements];
    }
    void add(const Shape & s) {
        if (numShapes == maxElements) return;
        sArray[numShapes++] = s.clone();
    }
    void print() {
        for (int i=0; i<numShapes; i++) {
            sArray[i]->print();
            cout << endl;
        }
    }
    virtual void draw() {
        for (int i=0; i<numShapes; i++)
            sArray[i]->draw();
    }
    virtual ~Canvas() {
        for (int i=0; i<numShapes; i++)
            delete sArray[i];
        delete[] sArray;
    }
};

} // namespace SimpleGeom

#endif // SIMPLEGEOM_H_INCLUDED
