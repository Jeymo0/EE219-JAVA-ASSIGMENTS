/*******************************************
 SimpleGeom drawing examples
********************************************/

#include "SimpleGeom.h"
#include <cstdlib>

using namespace SimpleGeom;

/*******************************************
 Create a regular polygon
 Call this method with either of:
 polygon <GLLine> (canvas, numSides);
 polygon <JSLine> (canvas, numSides);
********************************************/
template<class LineType>
void polygon(Canvas & canvas, int numSides = 6, Color clr = BLUE, double x = 0, double y = 0) {
    double interiorAngle = (numSides-2)*PI/numSides;
    Coord c1(250+x, 400+y), c2(250+x + 800/numSides, 400+y);
    for (int i=0; i<numSides; i++) {
        canvas.add(LineType(c1,c2,clr));
        if (i % 2) c2.rotate(interiorAngle,c1);
        else c1.rotate(interiorAngle,c2);
    }
}

/*******************************************
 Create some random points
 Call this method with either of:
 randomPoints <GLPoint> (canvas);
 randomPoints <JSPoint> (canvas);
********************************************/
template<class PointType>
void randomPoints(Canvas & canvas) {
    for (int i=0; i<500; i++) {
        Coord coord(800.0*rand()/(double)RAND_MAX + 10, 800.0*rand()/(double)RAND_MAX + 10);
        PointType p(coord, Color(0.4,0.5,0.8));
        canvas.add(p);
    }
}

/*******************************************
 Create a circular pattern with triangles
 Call this method with either of:
 triangleFun <GLPoint,GLTriangle> (canvas);
 triangleFun <JSPoint,JSTriangle> (canvas);
********************************************/
template<class PointType, class TriangleType>
void triangleFun(Canvas & canvas) {
    Coord c1(400,400);
    PointType p1(c1,RED);
    canvas.add(p1);
    TriangleType tri(c1, Coord(400,900), Coord(800,400), BLUE);
    for (int i=0; i<50; i++) {
        tri.setColor(BLUE);
        canvas.add(tri);
        canvas.add(p1);
        tri.rotate(2*PI/50, Coord(500,500));
        p1.rotate(2*PI/50, Coord(500,500));
    }
}

/*******************************************
 Create random line segments and find their
 intersection points
 Call this method with either of:
 intersectLines <GLPoint,GLTriangle> (canvas);
 intersectLines <JSPoint,JSTriangle> (canvas);
********************************************/
template<class PointType, class LineType>
void intersectLines(Canvas & canvas, int numLines = 100) {
    // Create an array of random line segments and add them to canvas
    LineType** lines = new LineType*[numLines];
    for (int i=0; i<numLines; i++) {
        Coord c1(800.0*rand()/(double)RAND_MAX + 10, 800.0*rand()/(double)RAND_MAX + 10);
        Coord c2(800.0*rand()/(double)RAND_MAX + 10, 800.0*rand()/(double)RAND_MAX + 10);
        lines[i] = new LineType(c1, c2, DARK_BLUE);
        canvas.add(*lines[i]);
    }
    // Find intersection points between all line pairs and add points to canvas
    for (int i=0; i<numLines; i++) {
        for (int j=i; j<numLines; j++) {
            Coord icoord = Line::intersection(*lines[i], *lines[j]);
            if (!icoord.isEqual(NULL_COORD))
                canvas.add(PointType(icoord, RED));
        }
    }
    // Free memory
    for (int i=0; i<numLines; i++) delete lines[i];
        delete[] lines;
}

/*******************************************
 Create three trees (a small forest:)
 Call this method with either of:
 fractalTrees <GLPoint,GLLine> (canvas);
 fractalTrees <JSPoint,JSLine> (canvas);
********************************************/
template<class PointType, class LineType>
void fractalTree(Canvas & canvas, int x1=600, int y1=950, double angle=-PI/2, int len=300) {
    if (len < 5) { canvas.add(PointType(Coord(x1,y1),DARK_GREEN)); return; }
    int x2 = len * cos(angle) + x1;
    int y2 = len * sin(angle) + y1;
    canvas.add(LineType(Coord(x1,y1),Coord(x2,y2),Color(0.45,0.35,0.25)));
    fractalTree <PointType,LineType> (canvas, (x2-x1)/(2.0) + x1, (y2-y1)/(2.0) + y1, angle+0.26, len-36);
    fractalTree <PointType,LineType> (canvas, (x2-x1)/(3.0) + x1, (y2-y1)/(3.0) + y1, angle-0.3, len-28);
}
template<class PointType, class LineType>
void fractalTrees(Canvas & canvas) {
    fractalTree <PointType,LineType> (canvas,  700, 900, -PI/2, 325);
    fractalTree <PointType,LineType> (canvas, 1220, 900, -PI/2, 260);
    fractalTree <PointType,LineType> (canvas, 1500, 900, -PI/2, 190);
}
